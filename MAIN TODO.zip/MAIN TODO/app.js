let add =()=>{

let todo = document.getElementById('todo');


firebase.database().ref('todos').push({todo:todo.value})
todo.value= ""

}
firebase.database().ref('todos').on('child_added',(data)=>{
    console.log(data.key)
    let list = document.getElementById('list');
list.innerHTML +=`
<li>
<div class="list-card">

    <div>
 
    <input id ="${data.key}" type ="text" value ="  ${ data.val().todo}" disabled/>

    

    </div>




<div>
<button   onclick="editBtn('${data.key}')"  type="button" class="btn btn-warning">EDIT</button>
<button  onclick="delTodo('${data.key}')" type="button" class="btn btn-danger">Delete</button>
</div>
</div>



</li>

`
})

let del=()=>{
    firebase.database().ref('todos').remove()
    let list = document.getElementById('list');
    list.innerHTML=""


}

let delTodo = (key)=>{
// console.log(key)
firebase.database().ref(`todos/${key}`).remove()
event.target.parentNode.parentNode.remove()



}
let editBtn =(id)=>{
    let input= document.getElementById('id')
    input.disabled = false
    console.log(input)


}